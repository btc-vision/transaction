import { Wallet } from '../keypair/Wallet.js';
import { Regtest } from './Regtest.js';
import { OPNetLimitedProvider } from '../utxo/OPNetLimitedProvider.js';
import { FetchUTXOParamsMultiAddress, UTXO } from '../utxo/interfaces/IUTXO.js';
import { IInteractionParameters } from '../transaction/interfaces/ITransactionParameters.js';
import { networks } from 'bitcoinjs-lib';
import { TransactionFactory } from '../transaction/TransactionFactory.js';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { ABICoder, BinaryWriter } from '@btc-vision/bsi-binary';

const network: networks.Network = networks.regtest;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Regtest.wallet, network);

const utxoManager: OPNetLimitedProvider = new OPNetLimitedProvider('http://localhost:9001');
const factory: TransactionFactory = new TransactionFactory();

const abiCoder: ABICoder = new ABICoder();
const transferSelector = Number(`0x` + abiCoder.encodeSelector('mintAndApproveWBTC'));

function getTransferToCalldata(to: string, amount: bigint): Buffer {
    const addCalldata: BinaryWriter = new BinaryWriter();
    addCalldata.writeSelector(transferSelector);
    addCalldata.writeU256(amount);
    addCalldata.writeAddress(to);

    return Buffer.from(addCalldata.getBuffer());
}

const shouldMineBlock: boolean = true;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);

    return !!ok.length;
}

await rpc.init(Regtest.config);
const requestedAmount: bigint = 10000000000000n; //1n *
const utxoSetting: FetchUTXOParamsMultiAddress = {
    addresses: [wallet.p2wpkh, wallet.p2tr],
    minAmount: 10000n,
    requestedAmount: requestedAmount,
};

const utxos: UTXO[] = await utxoManager.fetchUTXOMultiAddr(utxoSetting);
console.log(`UTXOs:`, utxos);

try {
    for (let i = 0; i < 3000; i++) {
        if (!utxos) {
            console.log(`Used all UTXOs`);
            throw new Error('No UTXOs found');
        }

        const calldata: Buffer = getTransferToCalldata(
            'bcrt1p4q7vkuvy9k0cez7vs4cp9yuwqxafesmdgtu0g5928w9cdvtax54snmucw8',
            520000n,
        );

        const utxo = utxos.shift();
        if (!utxo) {
            break;
        }

        const interactionParameters: IInteractionParameters = {
            from: wallet.p2wpkh,
            to: 'bcrt1qs3re7ly4we7wtwncfcv22xcsmas0gngalazm9f',
            utxos: [utxo],
            signer: wallet.keypair,
            network: network,
            feeRate: 1000,
            priorityFee: 100000n,
            calldata: calldata,
        };

        try {
            const finalTx = factory.signInteraction(interactionParameters);
            const firstTxBroadcast = await rpc
                .sendRawTransaction({
                    hexstring: finalTx[0],
                })
                .catch((e) => {});

            console.log(`First transaction broadcasted: ${firstTxBroadcast}`);

            if (!firstTxBroadcast) {
                //throw new Error('Could not broadcast first transaction');
                continue;
            }

            const secondTxBroadcast = await rpc
                .sendRawTransaction({
                    hexstring: finalTx[1],
                })
                .catch((e) => {});

            console.log(`Second transaction broadcasted: ${secondTxBroadcast}`);

            if (!secondTxBroadcast) {
                //throw new Error('Could not broadcast second transaction');
            }
        } catch (e) {}
    }
} catch (e) {
    console.error(e);
}

console.log(`All transactions broadcasted`);
if (shouldMineBlock) {
    await mineBlock();
}

rpc.destroy();
