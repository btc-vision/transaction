import { Wallet } from '../keypair/Wallet.js';
import { Regtest } from './Regtest.js';
import { OPNetLimitedProvider } from '../utxo/OPNetLimitedProvider.js';
import { networks, Psbt, Signer } from 'bitcoinjs-lib';
import { TransactionFactory } from '../transaction/TransactionFactory.js';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { FetchUTXOParamsMultiAddress, UTXO } from '../utxo/interfaces/IUTXO.js';
import { IUnwrapParameters } from '../transaction/interfaces/ITransactionParameters.js';
import { EcKeyPair } from '../keypair/EcKeyPair.js';
import { MultiSignTransaction } from '../transaction/builders/MultiSignTransaction.js';

const network: networks.Network = networks.regtest;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Regtest.wallet, network);

const opnet: OPNetLimitedProvider = new OPNetLimitedProvider('http://localhost:9001');
const factory: TransactionFactory = new TransactionFactory();

const shouldMineBlock: boolean = false;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);

    return !!ok.length;
}

await rpc.init(Regtest.config);

const utxoSetting: FetchUTXOParamsMultiAddress = {
    addresses: [wallet.p2wpkh, wallet.p2tr],
    minAmount: 10000n,
    requestedAmount: 300000n,
};

const utxos: UTXO[] = await opnet.fetchUTXOMultiAddr(utxoSetting);
if (!utxos) {
    throw new Error('No UTXOs found');
}

const unwrapAmount: bigint = 300000n;
const unwrapUtxos = await opnet.fetchUnWrapParameters(unwrapAmount, wallet.p2tr);
if (!unwrapUtxos) {
    throw new Error('No UTXOs found for unwrap');
}

const unwrapParameters: IUnwrapParameters = {
    from: wallet.p2tr,

    utxos: utxos,
    unwrapUTXOs: unwrapUtxos.vaultUTXOs,

    signer: wallet.keypair,
    network: network,
    feeRate: 100,

    priorityFee: 10000n,
    amount: unwrapAmount,
};

const finalTx = await factory.unwrap(unwrapParameters);

const pubkeys: Buffer[] = [
    'AtOOpbDsniLbs2QGuqPFu7AnCOK9lNSSl+pvPr0m0Yx3',
    'AgPmjuI2/MNJM9STswWm8MdWEllHHRPs0Q3+DjdjOny+',
    'A4JEwTBwTx5QaLCFORTow27UQvkLQWZguhz6N+d8FczI',
    'A7ZKMoDQJlcQNbzIikCE5MPiFC81RvHHTeTMRx2/bFiO',
]
    .map((key) => Buffer.from(key, 'base64'))
    .sort((a, b) => a.compare(b));

const rlSigner2 = EcKeyPair.fromPrivateKey(
    Buffer.from('c3878546c453bca783fd91965218242eecc32d5443764d4a7f233ff018f002e0', 'hex'),
    network,
);

const realSigner = Wallet.fromWif('cRHbWamSVDkJWwjq5vMtriuFsWcptWmA7z8Nkqotk9vJ891KMBXc', network);

console.log('FUNDING', finalTx.fundingTransaction);

const removedFirstTwoChar = finalTx.psbt.slice(4);
const psbtTransaction2 = Psbt.fromHex(removedFirstTwoChar, { network });
const signed3 = MultiSignTransaction.signPartial(
    psbtTransaction2,
    rlSigner2 as Signer,
    1,
    [2, 2, 2, 2],
);

const finalized = MultiSignTransaction.attemptFinalizeInputs(
    psbtTransaction2,
    1,
    [pubkeys, pubkeys, pubkeys, pubkeys],
    false,
);
console.log(`Signed`, signed3, finalized);

const signed4 = MultiSignTransaction.signPartial(
    psbtTransaction2,
    realSigner.keypair,
    1,
    [2, 2, 2, 2],
);
const finalized2 = MultiSignTransaction.attemptFinalizeInputs(
    psbtTransaction2,
    1,
    [pubkeys, pubkeys, pubkeys, pubkeys],
    true,
);
console.log(`Signed`, signed4, finalized2);

const final = psbtTransaction2.extractTransaction().toHex();
console.log(`Finalized`, final);

/*const tx2 = await opnet.broadcastTransaction(finalTx.fundingTransaction, false);
console.log(`Broadcasted:`, tx2);

const tx3 = await opnet.broadcastTransaction(finalTx.psbt, true);
console.log(`Broadcasted:`, tx3);*/

if (shouldMineBlock) {
    await mineBlock();
}

rpc.destroy();
