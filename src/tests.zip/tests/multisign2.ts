import { networks } from 'bitcoinjs-lib';
import { Testnet } from './Regtest.js';
import { Wallet } from '../keypair/Wallet.js';
import { UTXO } from '../utxo/interfaces/IUTXO.js';
import { EcKeyPair } from '../keypair/EcKeyPair.js';

const base64 =
    'cHNidP8BAFICAAAAASNIxwwrZsoFQXkT+/iZFGZfE3nASG6UKlzzp/GqP9aYAAAAAAD9////ARAnAAAAAAAAFgAU3A1GB3oiXLyahEdQ+brLnuXu1PkAAAAAAAEA9wIAAAAAAQEEp9c4x0mHzuAx2zITbeG/URike79ng12YAsPWhjeVMQEAAAAA/f///wJa9gEAAAAAACJRIJydkNXcZzrZZbyLbPYkpFoAcRisalctr79rPmez8uPUtMs2kwAAAAAiUSDL4fsq34Gxa6Svuzh0P0c4zLKBcNLvw1o8qTZs5k6kUQJIMEUCIQDDhiqYy+HKDXywY3kHHNYirdVCcuOnaOJsaHrHoFg1/QIgd1TXcUzslGOAdvTSpvuTCh1mWlUGQyXK4p1Pgs8qWZwBIQIDc2JtMXroeIzjKAtJEGhhDYQMI+y2TBQHW7ufZwr1LAAAAAABASta9gEAAAAAACJRIJydkNXcZzrZZbyLbPYkpFoAcRisalctr79rPmez8uPUAQj9mwEGFNwNRgd6Ily8moRHUPm6y57l7tT5IANzYm0xeuh4jOMoC0kQaGENhAwj7LZMFAdbu59nCvUsQWnmKwWlC3PzllTD3UronjfKtL59X3OaJioXxozhodCWtPNSXzdT5dQcS3R4PssChqtXhsr87NaJjVlbePJlHS2DQecQkmGe3r7lcT5nGv6XIvtUpkc2ZdQ0RXiY2g5AYh42Aq8T1EJh4VB7j1z9c135oTxlkuXmAikGlrmhxEuysCCDnSADc2JtMXroeIzjKAtJEGhhDYQMI+y2TBQHW7ufZwr1LK0gKezyFtE0GBZRLpSp/uGv1o4OVHTiXfBiHSd+K6+SnZytqRRr4RFHLP9N9MIFIGHGxZKfve2OvYipFFfTvUOjMKawg5fnZ94W/TVaiC75iHRRnGMDYnNpTx4fiwgAAAAAAAIKa52/5igDPsC+UAEALs4PKSQAAABnUWhBwANzYm0xeuh4jOMoC0kQaGENhAwj7LZMFAdbu59nCvUs5+TVk/y3KSbu2+DR4xH0Gs1vbvFh3LoIGnUWjsTc03kAAA==';

const network = networks.testnet;
const wallet = new Wallet(Testnet.wallet, network);

const pubkeys: Buffer[] = [
    'AgPmjuI2/MNJM9STswWm8MdWEllHHRPs0Q3+DjdjOny+',
    'AtOOpbDsniLbs2QGuqPFu7AnCOK9lNSSl+pvPr0m0Yx3',
    'A4JEwTBwTx5QaLCFORTow27UQvkLQWZguhz6N+d8FczI',
    'A7ZKMoDQJlcQNbzIikCE5MPiFC81RvHHTeTMRx2/bFiO',
].map((key) => Buffer.from(key, 'base64'));

/** --- */
const utxos: UTXO[] = [
    {
        transactionId: '2d05a02d5e3650f993ca75fe5e8a170fd4fe32347998bf3ee5eda089c259ae16',
        outputIndex: 1,
        value: 100000000n,
        scriptPubKey: {
            address: 'bcrt1ptksjlcd4ch722978mzggv8a6ywqqn64a25u6fz6syl0c37mg6q3s9rgu0k',
            hex: Buffer.from('USBdoS/htcX8pRfH2JCGH7ojgAnqvVU5pItQJ9+I+2jQIw==', 'base64').toString(
                'hex',
            ),
        },
    },
];

const realSigner = Wallet.fromWif('cRHbWamSVDkJWwjq5vMtriuFsWcptWmA7z8Nkqotk9vJ891KMBXc', network);
const idk = EcKeyPair.generateMultiSigAddress(pubkeys, 2, network);

console.log(idk, wallet.p2tr);
