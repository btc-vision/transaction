import { TapscriptVerificator } from '../verification/TapscriptVerificator.js';
import { networks } from 'bitcoinjs-lib';
import { Regtest } from './Regtest.js';
import { Wallet } from '../keypair/Wallet.js';
import { EcKeyPair } from '../keypair/EcKeyPair.js';
import { ABICoder, BinaryWriter } from '@btc-vision/bsi-binary';

const walletTest = new Wallet(Regtest.wallet, networks.testnet);
console.log(walletTest);

const wallet = new Wallet(Regtest.wallet, networks.regtest);
console.log(wallet);

const selector = new ABICoder().encodeSelector('approve');
console.log('selector', Number(`0x${selector}`), selector);

const balanceOf: number = Number('0x' + new ABICoder().encodeSelector('balanceOf'));

const balanceCall = new BinaryWriter();
balanceCall.writeSelector(balanceOf);
balanceCall.writeAddress('bcrt1pe0slk2klsxckhf90hvu8g0688rxt9qts6thuxk3u4ymxeejw52gs0xjlhn');

console.log('balanceOf', balanceOf, Buffer.from(balanceCall.getBuffer()).toString('hex'));

const rndGeneratedRegWallet = EcKeyPair.generateWallet(networks.regtest);
const rndWallet = new Wallet(rndGeneratedRegWallet, networks.regtest);

console.log('rnd', rndWallet);

const params = {
    bytecode: Buffer.from('deadbeef', 'hex'),
    contractSaltPubKey: Buffer.from('deadbeef', 'hex'),
    deployerPubKeyXOnly: wallet.xOnly,
    originalSalt: Buffer.from('deadbeef', 'hex'),
    network: networks.regtest,
};

const contractAddress = TapscriptVerificator.getContractAddress(params);
const virtualAddress: string = TapscriptVerificator.generateContractVirtualAddress(
    params.deployerPubKeyXOnly,
    params.bytecode,
    params.originalSalt,
    networks.regtest,
);

console.log('contract sewgit address', virtualAddress, '\ncontract p2tr address', contractAddress);
