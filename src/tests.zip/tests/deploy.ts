import { Wallet } from '../keypair/Wallet.js';
import { Testnet } from './Regtest.js';
import { OPNetLimitedProvider } from '../utxo/OPNetLimitedProvider.js';
import { networks } from 'bitcoinjs-lib';
import { TransactionFactory } from '../transaction/TransactionFactory.js';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { FetchUTXOParamsMultiAddress, UTXO } from '../utxo/interfaces/IUTXO.js';
import { IDeploymentParameters } from '../transaction/interfaces/ITransactionParameters.js';
import * as fs from 'node:fs';

const network: networks.Network = networks.testnet;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Testnet.wallet, network);

const utxoManager: OPNetLimitedProvider = new OPNetLimitedProvider('https://testnet.opnet.org');
const factory: TransactionFactory = new TransactionFactory();

const shouldMineBlock: boolean = true;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);

    return !!ok.length;
}

await rpc.init(Testnet.config);

const utxoSetting: FetchUTXOParamsMultiAddress = {
    addresses: [wallet.p2tr, wallet.p2wpkh],
    minAmount: 10000n,
    requestedAmount: 100000n,
};

console.log(utxoSetting);

const utxos: UTXO[] = await utxoManager.fetchUTXOMultiAddr(utxoSetting);
if (!utxos) {
    throw new Error('No UTXOs found');
}

const bytecode = fs.readFileSync('./bytecode/wbtc.wasm');
const deploymentParameters: IDeploymentParameters = {
    from: wallet.p2wpkh,
    utxos: utxos,
    signer: wallet.keypair,
    network: network,
    feeRate: 1000,
    priorityFee: 50000n,
    bytecode: bytecode,
};

const finalTx = factory.signDeployment(deploymentParameters);
console.log(`Final transaction:`, finalTx);

const firstTxBroadcast = await rpc.sendRawTransaction({
    hexstring: finalTx.transaction[0],
});

console.log(`First transaction broadcasted: ${firstTxBroadcast}`);

if (!firstTxBroadcast) {
    throw new Error('Could not broadcast first transaction');
}

const secondTxBroadcast = await rpc.sendRawTransaction({
    hexstring: finalTx.transaction[1],
});

console.log(`Second transaction broadcasted: ${secondTxBroadcast}`);

if (!secondTxBroadcast) {
    throw new Error('Could not broadcast second transaction');
}

if (shouldMineBlock) {
    await mineBlock();
}
