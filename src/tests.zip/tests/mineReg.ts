import { Wallet } from '../keypair/Wallet.js';
import { Regtest } from './Regtest.js';
import { networks } from 'bitcoinjs-lib';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';

const network: networks.Network = networks.regtest;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Regtest.wallet, network);

const shouldMineBlock: boolean = true;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);
    return !!ok.length;
}

await rpc.init(Regtest.config);

if (shouldMineBlock) {
    await mineBlock();
}

rpc.destroy();
