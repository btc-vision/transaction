import { Wallet } from '../keypair/Wallet.js';
import { Testnet } from './Regtest.js';
import { OPNetLimitedProvider } from '../utxo/OPNetLimitedProvider.js';
import { networks } from 'bitcoinjs-lib';
import { TransactionFactory } from '../transaction/TransactionFactory.js';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { IWrapParameters } from '../transaction/interfaces/ITransactionParameters.js';
import { FetchUTXOParamsMultiAddress, UTXO } from '../utxo/interfaces/IUTXO.js';

const network: networks.Network = networks.testnet;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Testnet.wallet, network);

const opnet: OPNetLimitedProvider = new OPNetLimitedProvider('https://testnet.opnet.org');
const factory: TransactionFactory = new TransactionFactory();
const shouldMineBlock: boolean = true;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);

    return !!ok.length;
}

await rpc.init(Testnet.config);

const wrapAmount: bigint = 1n * 100000000n;
const utxoSetting: FetchUTXOParamsMultiAddress = {
    addresses: [wallet.p2wpkh, wallet.p2tr],
    minAmount: 10000n,
    requestedAmount: wrapAmount,
};

const utxos: UTXO[] = await opnet.fetchUTXOMultiAddr(utxoSetting);
if (!utxos) {
    throw new Error('No UTXOs found');
}

const generationParameters = await opnet.fetchWrapParameters(wrapAmount);
if (!generationParameters) {
    throw new Error('No generation parameters found');
}

const wrapParameters: IWrapParameters = {
    from: wallet.p2wpkh,

    utxos: utxos,
    signer: wallet.keypair,
    network: network,
    feeRate: 500,
    priorityFee: 50000n,

    receiver: wallet.p2tr,

    amount: wrapAmount,
    generationParameters: generationParameters,
};

const finalTx = factory.wrap(wrapParameters);
console.log(`Final transaction:`, finalTx);

const firstTxBroadcast = await rpc.sendRawTransaction({
    hexstring: finalTx.transaction[0],
});

console.log(`First transaction broadcasted: ${firstTxBroadcast}`);

if (!firstTxBroadcast) {
    throw new Error('Could not broadcast first transaction');
}

const secondTxBroadcast = await rpc.sendRawTransaction({
    hexstring: finalTx.transaction[1],
});

console.log(`Second transaction broadcasted: ${secondTxBroadcast}`);

if (!secondTxBroadcast) {
    throw new Error('Could not broadcast second transaction');
}

if (shouldMineBlock) {
    await mineBlock();
}

rpc.destroy();
