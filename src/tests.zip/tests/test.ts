import { Wallet } from '../keypair/Wallet.js';
import { Regtest } from './Regtest.js';
import { OPNetLimitedProvider } from '../utxo/OPNetLimitedProvider.js';
import { FetchUTXOParams, UTXO } from '../utxo/interfaces/IUTXO.js';
import { IFundingTransactionParameters } from '../transaction/interfaces/ITransactionParameters.js';
import { networks } from 'bitcoinjs-lib';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { FundingTransaction } from '../transaction/builders/FundingTransaction.js';

const network: networks.Network = networks.regtest;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Regtest.wallet, network);

const utxoManager: OPNetLimitedProvider = new OPNetLimitedProvider('http://localhost:9001');
const shouldMineBlock: boolean = true;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);
    return !!ok.length;
}

(async () => {
    await rpc.init(Regtest.config);

    const utxoSetting: FetchUTXOParams = {
        address: wallet.p2wpkh,
        minAmount: 10000n,
        requestedAmount: 100000n,
    };

    const utxos: UTXO[] = await utxoManager.fetchUTXO(utxoSetting);
    if (!utxos) {
        throw new Error('No UTXOs found');
    }

    const interactionParameters: IFundingTransactionParameters = {
        from: wallet.p2wpkh,
        to: 'bcrt1qqvf4gprr05z248ph6gvx54rpg08p8ngq3zh8uh',
        utxos: utxos,
        signer: wallet.keypair,
        network: network,
        feeRate: 150,
        priorityFee: 1000n,
        childTransactionRequiredValue: 0n,
    };

    const fundingTransaction = new FundingTransaction(interactionParameters);
    const fundingTx = fundingTransaction.signTransaction();
    console.log(fundingTx.toHex());

    const secondTxBroadcast = await rpc.sendRawTransaction({
        hexstring: fundingTx.toHex(),
    });
    console.log(`Transaction broadcasted: ${secondTxBroadcast}`);

    if (shouldMineBlock) {
        await mineBlock();
    }
})();
