import { Wallet } from '../keypair/Wallet.js';
import { Regtest } from './Regtest.js';
import { networks } from 'bitcoinjs-lib';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { ABICoder, BinaryWriter } from '@btc-vision/bsi-binary';

const network: networks.Network = networks.regtest;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Regtest.wallet, network);

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);

    return !!ok.length;
}

await rpc.init(Regtest.config);

const wrapAmount: bigint = 1n * 100000000n;

const abiCoder: ABICoder = new ABICoder();
const transferSelector = Number(`0x` + abiCoder.encodeSelector('totalStaked'));

function generateCalldata(to: string, amount: bigint): Buffer {
    const addCalldata: BinaryWriter = new BinaryWriter();
    addCalldata.writeSelector(transferSelector);
    //addCalldata.writeU256(amount);
    //addCalldata.writeAddress(to);

    return Buffer.from(addCalldata.getBuffer());
}

const call = generateCalldata(wallet.p2tr, wrapAmount);
console.log('call', call.toString('hex'));

rpc.destroy();
