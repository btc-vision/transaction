import { Wallet } from '../keypair/Wallet.js';
import { Regtest } from './Regtest.js';
import { OPNetLimitedProvider } from '../utxo/OPNetLimitedProvider.js';
import { FetchUTXOParamsMultiAddress, UTXO } from '../utxo/interfaces/IUTXO.js';
import { IWrapParameters } from '../transaction/interfaces/ITransactionParameters.js';
import { networks } from 'bitcoinjs-lib';
import { TransactionFactory } from '../transaction/TransactionFactory.js';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { currentConsensusConfig } from '../consensus/ConsensusConfig.js';

const network: networks.Network = networks.regtest;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Regtest.wallet, network);

const utxoManager: OPNetLimitedProvider = new OPNetLimitedProvider('http://localhost:9001');
const factory: TransactionFactory = new TransactionFactory();

const shouldMineBlock: boolean = true;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);

    return !!ok.length;
}

await rpc.init(Regtest.config);
const requestedAmount: bigint = 10000000000000n; //1n *
const utxoSetting: FetchUTXOParamsMultiAddress = {
    addresses: [wallet.p2wpkh, wallet.p2tr],
    minAmount: 10000n,
    requestedAmount: requestedAmount,
};

const utxos: UTXO[] = await utxoManager.fetchUTXOMultiAddr(utxoSetting);
let totalAmount: bigint = 0n;
try {
    for (let i = 0; i < 120; i++) {
        if (!utxos) {
            console.log(`Used all UTXOs`);
            throw new Error('No UTXOs found');
        }

        const utxo = utxos.shift();
        if (!utxo) {
            console.log(`Used all UTXOs`);
            break;
        }

        const wrapAmount: bigint =
            currentConsensusConfig.VAULT_MINIMUM_AMOUNT +
            (currentConsensusConfig.VAULT_MINIMUM_AMOUNT *
                10000000n *
                BigInt(Math.floor(Math.random() * 10000))) /
                10000000000n;

        if (wrapAmount < currentConsensusConfig.VAULT_MINIMUM_AMOUNT) {
            console.log(`Wrap amount too low: ${wrapAmount}`);
            i--;
            continue;
        }

        try {
            const generationParameters = await utxoManager.fetchWrapParameters(wrapAmount);
            if (!generationParameters) {
                throw new Error('No generation parameters found');
            }

            const interactionParameters: IWrapParameters = {
                from: wallet.p2wpkh,
                utxos: [utxo],
                signer: wallet.keypair,
                network: network,
                feeRate: 500,
                priorityFee: 100000n,

                receiver: wallet.p2tr,

                amount: wrapAmount,
                generationParameters: generationParameters,
            };

            const finalTx = factory.wrap(interactionParameters);
            const firstTxBroadcast = await rpc
                .sendRawTransaction({
                    hexstring: finalTx.transaction[0],
                })
                .catch(() => {});

            console.log(`First transaction broadcasted: ${firstTxBroadcast}`);

            if (!firstTxBroadcast) {
                i--;
                continue;
            }

            const secondTxBroadcast = await rpc
                .sendRawTransaction({
                    hexstring: finalTx.transaction[1],
                })
                .catch(() => {});

            console.log(`Second transaction broadcasted: ${secondTxBroadcast}`);

            if (!secondTxBroadcast) {
                throw new Error('Could not broadcast second transaction');
            } else {
                totalAmount += wrapAmount;
                //i++;
            }
        } catch (e) {
            console.log(e);
            i--;
        }
    }
} catch (e) {
    console.error(e);
}

console.log(`All transactions broadcasted for a total of ${totalAmount} satoshis.`);
if (shouldMineBlock) {
    await mineBlock();
}

rpc.destroy();
