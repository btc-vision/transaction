import { Wallet } from '../keypair/Wallet.js';
import { Regtest } from './Regtest.js';
import { OPNetLimitedProvider } from '../utxo/OPNetLimitedProvider.js';
import { networks } from 'bitcoinjs-lib';
import { TransactionFactory } from '../transaction/TransactionFactory.js';
import { BitcoinRPC } from '@btc-vision/bsi-bitcoin-rpc';
import { FetchUTXOParamsMultiAddress, UTXO } from '../utxo/interfaces/IUTXO.js';
import { IUnwrapParameters } from '../transaction/interfaces/ITransactionParameters.js';
import { EcKeyPair } from '../keypair/EcKeyPair.js';
import { FromBase64Params, PsbtTransaction } from '../transaction/processor/PsbtTransaction.js';
import { currentConsensusConfig } from '../consensus/ConsensusConfig.js';

const network: networks.Network = networks.regtest;
const rpc: BitcoinRPC = new BitcoinRPC();
const wallet: Wallet = new Wallet(Regtest.wallet, network);

const opnet: OPNetLimitedProvider = new OPNetLimitedProvider('http://localhost:9001');
const factory: TransactionFactory = new TransactionFactory();

const shouldMineBlock: boolean = true;

async function mineBlock(): Promise<boolean> {
    // lets mine 1 block.
    const ok = await rpc.generateToAddress(1, wallet.p2wpkh, 'default');
    if (!ok) {
        throw new Error('Could not mine block');
    }

    console.log(`Mined block`, ok);

    return !!ok.length;
}

await rpc.init(Regtest.config);

const utxoSetting: FetchUTXOParamsMultiAddress = {
    addresses: [wallet.p2wpkh, wallet.p2tr],
    minAmount: 10000n,
    requestedAmount: 300000n,
};

const utxos: UTXO[] = await opnet.fetchUTXOMultiAddr(utxoSetting);
if (!utxos) {
    throw new Error('No UTXOs found');
}

const unwrapAmount: bigint = currentConsensusConfig.VAULT_MINIMUM_AMOUNT;
const unwrapUtxos = await opnet.fetchUnWrapParameters(unwrapAmount, wallet.p2tr);
if (!unwrapUtxos) {
    throw new Error('No UTXOs found for unwrap');
}

const unwrapParameters: IUnwrapParameters = {
    from: wallet.p2tr,

    utxos: utxos,
    unwrapUTXOs: unwrapUtxos.vaultUTXOs,

    signer: wallet.keypair,
    network: network,
    feeRate: 100,

    priorityFee: 10000n,

    amount: unwrapAmount,
};

const finalTx = await factory.unwrapSegwit(unwrapParameters);
console.log(finalTx.psbt, finalTx.fundingTransaction);

const rlSigner2 = EcKeyPair.fromPrivateKey(
    Buffer.from('c3878546c453bca783fd91965218242eecc32d5443764d4a7f233ff018f002e0', 'hex'),
    network,
);

const psbtTransactionData2: FromBase64Params = {
    signer: rlSigner2,
    network: network,
};

const removedFirstTwoChar = finalTx.psbt.slice(2);

const psbtTransaction2 = PsbtTransaction.fromHex(removedFirstTwoChar, psbtTransactionData2);
const s = psbtTransaction2.attemptSignAllInputs();
const f = psbtTransaction2.attemptFinalizeInputs(1);

const newPsbt = psbtTransaction2.toHex();
console.log(s, f, newPsbt);

const realSigner = Wallet.fromWif('cRHbWamSVDkJWwjq5vMtriuFsWcptWmA7z8Nkqotk9vJ891KMBXc', network);
const psbtTransactionData3: FromBase64Params = {
    signer: realSigner.keypair,
    network: network,
};

const psbtTransaction3 = PsbtTransaction.fromHex(newPsbt, psbtTransactionData3);
const s2 = psbtTransaction3.attemptSignAllInputs();
const f2 = psbtTransaction3.attemptFinalizeInputs(1);

if (f2) {
    console.log('TRANSACTION IS FINALIZED.');

    const finalized = psbtTransaction3.final();
    console.log('Finalized:', finalized);

    const tx2 = await opnet.broadcastTransaction(finalTx.fundingTransaction, false);
    console.log(`Broadcasted:`, tx2);

    const tx3 = await opnet.broadcastTransaction(finalized, false);
    console.log(`Broadcasted:`, tx3);

    await mineBlock();
} else {
    throw new Error('Transaction is not finalized');
}

/*const tx = await opnet.broadcastTransaction(finalTx.fundingTransaction, false);
console.log(`Broadcasted:`, tx);

const broadcastedPSBT = await opnet.broadcastTransaction(finalTx.psbt, true);
console.log(`Broadcasted PSBT:`, broadcastedPSBT);

//const broadcastedPSBT = await opnet.broadcastTransaction(finalTx.psbt, true);
//console.log(`Broadcasted PSBT:`, broadcastedPSBT);

//await mineBlock();

/*const firstTxBroadcast = await rpc.sendRawTransaction({
    hexstring: finalTx.transaction[0],
});

console.log(`First transaction broadcasted: ${firstTxBroadcast}`);

if (!firstTxBroadcast) {
    throw new Error('Could not broadcast first transaction');
}

const secondTxBroadcast = await rpc.sendRawTransaction({
    hexstring: finalTx.transaction[1],
});

console.log(`Second transaction broadcasted: ${secondTxBroadcast}`);

if (!secondTxBroadcast) {
    throw new Error('Could not broadcast second transaction');
}

if (shouldMineBlock) {
    await mineBlock();
}*/

rpc.destroy();
