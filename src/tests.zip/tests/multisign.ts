import { networks, Psbt, Signer } from 'bitcoinjs-lib';
import { Regtest } from './Regtest.js';
import { Wallet } from '../keypair/Wallet.js';
import { UTXO } from '../utxo/interfaces/IUTXO.js';
import {
    MultiSignParameters,
    MultiSignTransaction,
} from '../transaction/builders/MultiSignTransaction.js';
import { EcKeyPair } from '../keypair/EcKeyPair.js';

const base64 =
    'cHNidP8BAFICAAAAASNIxwwrZsoFQXkT+/iZFGZfE3nASG6UKlzzp/GqP9aYAAAAAAD9////ARAnAAAAAAAAFgAU3A1GB3oiXLyahEdQ+brLnuXu1PkAAAAAAAEA9wIAAAAAAQEEp9c4x0mHzuAx2zITbeG/URike79ng12YAsPWhjeVMQEAAAAA/f///wJa9gEAAAAAACJRIJydkNXcZzrZZbyLbPYkpFoAcRisalctr79rPmez8uPUtMs2kwAAAAAiUSDL4fsq34Gxa6Svuzh0P0c4zLKBcNLvw1o8qTZs5k6kUQJIMEUCIQDDhiqYy+HKDXywY3kHHNYirdVCcuOnaOJsaHrHoFg1/QIgd1TXcUzslGOAdvTSpvuTCh1mWlUGQyXK4p1Pgs8qWZwBIQIDc2JtMXroeIzjKAtJEGhhDYQMI+y2TBQHW7ufZwr1LAAAAAABASta9gEAAAAAACJRIJydkNXcZzrZZbyLbPYkpFoAcRisalctr79rPmez8uPUAQj9mwEGFNwNRgd6Ily8moRHUPm6y57l7tT5IANzYm0xeuh4jOMoC0kQaGENhAwj7LZMFAdbu59nCvUsQWnmKwWlC3PzllTD3UronjfKtL59X3OaJioXxozhodCWtPNSXzdT5dQcS3R4PssChqtXhsr87NaJjVlbePJlHS2DQecQkmGe3r7lcT5nGv6XIvtUpkc2ZdQ0RXiY2g5AYh42Aq8T1EJh4VB7j1z9c135oTxlkuXmAikGlrmhxEuysCCDnSADc2JtMXroeIzjKAtJEGhhDYQMI+y2TBQHW7ufZwr1LK0gKezyFtE0GBZRLpSp/uGv1o4OVHTiXfBiHSd+K6+SnZytqRRr4RFHLP9N9MIFIGHGxZKfve2OvYipFFfTvUOjMKawg5fnZ94W/TVaiC75iHRRnGMDYnNpTx4fiwgAAAAAAAIKa52/5igDPsC+UAEALs4PKSQAAABnUWhBwANzYm0xeuh4jOMoC0kQaGENhAwj7LZMFAdbu59nCvUs5+TVk/y3KSbu2+DR4xH0Gs1vbvFh3LoIGnUWjsTc03kAAA==';

const network = networks.regtest;
const wallet = new Wallet(Regtest.wallet, network);

const pubkeys: Buffer[] = [
    'AgPmjuI2/MNJM9STswWm8MdWEllHHRPs0Q3+DjdjOny+',
    'AtOOpbDsniLbs2QGuqPFu7AnCOK9lNSSl+pvPr0m0Yx3',
    'A7ZKMoDQJlcQNbzIikCE5MPiFC81RvHHTeTMRx2/bFiO',
    'A4JEwTBwTx5QaLCFORTow27UQvkLQWZguhz6N+d8FczI',
].map((key) => Buffer.from(key, 'base64'));

/** --- */
const utxos: UTXO[] = [
    {
        transactionId: '19ad15c5a73dd2b591d3269337025c7cda5d619eb872cf543bff531a2946a245',
        outputIndex: 1,
        value: 100000000n,
        scriptPubKey: {
            address: 'bcrt1pc6vdqqscqu4j8ktrc0558p4cmw8c3glqx4f80eflmtgwgu9r275svkax55',
            hex: Buffer.from('USDGmNACGAcrI9ljw+lDhrjbj4ij4DVSd+U/2tDkcKNXqQ==', 'base64').toString(
                'hex',
            ),
        },
    },
];

const realSigner = Wallet.fromWif('cRHbWamSVDkJWwjq5vMtriuFsWcptWmA7z8Nkqotk9vJ891KMBXc', network);
const rlSigner2 = EcKeyPair.fromPrivateKey(
    Buffer.from('c3878546c453bca783fd91965218242eecc32d5443764d4a7f233ff018f002e0', 'hex'),
    network,
);

//const psbt = Psbt.fromBase64(base64, { network: network });
const multiSignParams: MultiSignParameters = {
    network: network,
    utxos: utxos,
    pubkeys: pubkeys,
    minimumSignatures: 2,
    feeRate: 100,
    refundVault: 'bcrt1pc6vdqqscqu4j8ktrc0558p4cmw8c3glqx4f80eflmtgwgu9r275svkax55',
    receiver: wallet.p2tr,
    //signer: realSigner.keypair,
    requestedAmount: 600000n,
};

const multiSign = new MultiSignTransaction(multiSignParams);

const signed = multiSign.signPSBT();
const signed3 = MultiSignTransaction.signPartial(signed, rlSigner2 as Signer, 0, [2]);

/*MultiSignTransaction.signInputTaproot(
    signed,
    0,
    opnetVaultGenericWallet,
    [Transaction.SIGHASH_ALL | Transaction.SIGHASH_ANYONECANPAY],
    network,
    hash,
);*/

console.log(`Signed`, signed3, signed.toHex());

const signed2 = MultiSignTransaction.signPartial(signed, realSigner.keypair as Signer, 0, [2]);
console.log(`Signed`, signed2, signed.toHex());

const cloned2 = Psbt.fromBase64(signed.toBase64(), { network: network });
console.dir(cloned2, { depth: 10, colors: true });

/**/

const finalized = MultiSignTransaction.attemptFinalizeInputs(cloned2, 0, [], true);

// and THEN WE FINALIZE
//cloned2.finalizeAllInputs();

//const idk = MultiSignTransaction.attemptFinalizeInputs(cloned2, 1);
console.log(`Signed`, cloned2.extractTransaction(false).toHex(), finalized);

//console.log(signed.toBase64());

//const multiSign = new MultiSignTransaction

//const keyPair1 = EcKeyPair.generateRandomKeyPair(network);
//const keyPair2 = EcKeyPair.generateRandomKeyPair(network);

/*const p2ms = payments.p2ms({ m: 2, pubkeys, network: network });
const p2wsh = payments.p2wsh({ redeem: p2ms, network: network });
const p2sh = payments.p2sh({ redeem: p2wsh, network: network });

const p2shRedeem = p2sh.redeem?.output;
const p2wshRedeem = p2wsh.redeem?.output;
const p2wshOut = p2wsh.output;
if (!p2shRedeem || !p2wshRedeem || !p2wshOut) {
    throw new Error('P2SH Redeem output is required');
}

const taptree: Taptree = [
    {
        output: p2wshRedeem,
        version: 0xc0,
    },
    {
        output: p2wshRedeem,
        version: 0xc0,
    },
];

const internalKeyPair = EcKeyPair.generateRandomKeyPair(network);
const p2tr = payments.p2tr({
    internalPubkey: toXOnly(internalKeyPair.publicKey),
    scriptTree: taptree,
    network: regtest,
});

console.log('P2MS Address:', p2ms.address);
console.log('P2WSH Address:', p2wsh.address);
console.log('P2SH Address:', p2sh.address);
console.log('P2TR Address:', p2tr.address);

if (!p2tr.witness || !p2tr.output) {
    throw new Error('P2TR witness is required');
}

const controlBlock = p2tr.witness[p2tr.witness.length - 1];
console.log('Control Block:', controlBlock);

const fakeTxId = 'b1fea52499b9db0fb3f3a1a25b3153b9676826a7a342c3cd555ba820b8b3dd11';
const fakeVout = 1;

const validator = (pubkey: Buffer, msghash: Buffer, signature: Buffer): boolean =>
    EcKeyPair.fromPublicKey(pubkey).verify(msghash, signature);

const psbt = new Psbt({ network: network });
psbt.addInput({
    hash: fakeTxId,
    index: fakeVout,
    witnessUtxo: {
        script: p2tr.output, //Buffer.from('ACB2jiK9TsOg1gp7vSm6+OeypJZL6rWldarmodsCQM6Cow==', 'base64'),
        value: 520000, // value in satoshis
    },
    tapLeafScript: [
        {
            leafVersion: 0xc0, // Taproot default leaf version
            script: p2wshOut,
            controlBlock: controlBlock,
        },
    ],
    //redeemScript: p2shRedeem,
    //witnessScript: p2wshRedeem,
});
psbt.addOutput({
    address: 'mwCwTceJvYV27KXBc3NJZys6CjsgsoeHmf', // Random Regtest Address
    value: 49000,
});

//psbt.signInput(0, keyPair1);
//psbt.signInput(0, keyPair3);
//psbt.signInput(0, keyPair4);

// Step 6: Validate Signatures
const isValid = psbt.validateSignaturesOfInput(0, validator);
if (!isValid) {
    throw new Error('Invalid signatures');
}

// Step 7: Finalize the Inputs
psbt.finalizeAllInputs();

console.log(psbt);*/
