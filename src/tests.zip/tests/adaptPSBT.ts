import { networks, Psbt } from 'bitcoinjs-lib';
import {
    FromBase64Params,
    PsbtTransaction,
    VaultUTXOs,
} from '../transaction/processor/PsbtTransaction.js';
import { Regtest } from './Regtest.js';
import { Wallet } from '../keypair/Wallet.js';
import { EcKeyPair } from '../keypair/EcKeyPair.js';

const utxos: VaultUTXOs[] = [
    {
        vault: 'bcrt1ql3dff0w774f627ggw4ejt3pv04u7t73e2sjsqv5ff7qygrhlylzsdh0xna',
        publicKeys: [
            'AgPmjuI2/MNJM9STswWm8MdWEllHHRPs0Q3+DjdjOny+',
            'AtOOpbDsniLbs2QGuqPFu7AnCOK9lNSSl+pvPr0m0Yx3',
            'A4JEwTBwTx5QaLCFORTow27UQvkLQWZguhz6N+d8FczI',
            'A7ZKMoDQJlcQNbzIikCE5MPiFC81RvHHTeTMRx2/bFiO',
        ],
        minimum: 2,
        utxos: [
            {
                hash: '82a0d11689c8a5e7155c270a031a7a192f5fcba3a4260fc3510ebd4c73bfa6aa',
                blockId: 619n,
                output: 'ACD8WpS93vVTpXkIdXMlxCx9eeX6OVQlADKJT4BEDv8nxQ==',
                outputIndex: 1,
                value: 100000000n,
                vault: 'bcrt1ql3dff0w774f627ggw4ejt3pv04u7t73e2sjsqv5ff7qygrhlylzsdh0xna',
            },
        ],
    },
];

const base64 =
    '70736274ff010052020000000143a120458c2074a2cb6d08e8b741c18dd50615999b0448b6678748aa9a12906f0000000000fdffffff011027000000000000160014dc0d46077a225cbc9a844750f9bacb9ee5eed4f900000000000100f7020000000001014bc29a0c5878d0e34c7e0e76c97dedfa00daa56fe8210674ed31fb9e96ec16790100000000fdffffff025af601000000000022512058817b9610dc27498639d0c4ae8ca0113ba14da430ff6b78ae75292293212681275e83ec00000000225120cbe1fb2adf81b16ba4afbb38743f4738ccb28170d2efc35a3ca9366ce64ea45102483045022100a3552d46258d93b81dd9dcfaa57a6960cb9ae8d5009ff25940aca13c219eed6402202248161ab18a4741f5299fb8eab9274e2574d510f9cafac8277006a614bf308e0121020373626d317ae8788ce3280b491068610d840c23ecb64c14075bbb9f670af52c0000000001012b5af601000000000022512058817b9610dc27498639d0c4ae8ca0113ba14da430ff6b78ae752922932126810108fd9b010614dc0d46077a225cbc9a844750f9bacb9ee5eed4f9200373626d317ae8788ce3280b491068610d840c23ecb64c14075bbb9f670af52c4104964ea75ea30a5512ade2b830259a2eca4b21e1fd68699d3356b5d81ded56a5c5683236718cff2ed3e6201914039f1fb9f84ea06baa446e47854756421507258341da89e8c09e66a1fd759abe13e01bb0ecdd4fa85c2fb64fb62ea66b2ccaafbca7ceb99598f5f51485e71c55b45275c7643d5d1f757888647f0fb41a7ef9d56eab839d200373626d317ae8788ce3280b491068610d840c23ecb64c14075bbb9f670af52cad20e64ee717cbae471c72c6ed593ad376944885bcc38da475d24248fb49e2310f0dada9146be111472cff4df4c2052061c6c5929fbded8ebd88a91457d3bd43a330a6b08397e767de16fd355a882ef98874519c63036273694f1e1f8b080000000000020a6b9dbfe628033ec0be5001002ece0f292400000067516841c10373626d317ae8788ce3280b491068610d840c23ecb64c14075bbb9f670af52ce7e4d593fcb72926eedbe0d1e311f41acd6f6ef161dcba081a75168ec4dcd3790000';

const network = networks.regtest;
const wallet = new Wallet(Regtest.wallet, network);
const realSigner = Wallet.fromWif('cRHbWamSVDkJWwjq5vMtriuFsWcptWmA7z8Nkqotk9vJ891KMBXc', network);

//const myIndexerWallet1 = new Wallet(Regtest.wallet, network);
const originalTx = Psbt.fromHex(base64, { network: network });

//const psbt = new Psbt({ network: network });
//console.log(psbt.extractTransaction().toHex());

/*const psbtTransactionData: FromBase64Params = {
    signer: wallet.keypair,
    network: network,
    amountRequested: 10000n,
    receiver: wallet.p2tr,
};
const psbtTransaction = PsbtTransaction.fromBase64(psbt.toBase64(), psbtTransactionData);
psbtTransaction.mergeVaults(utxos);

console.log(psbtTransaction.toBase64());
console.log(originalTx.toBase64());*/

const rlSigner2 = EcKeyPair.fromPrivateKey(
    Buffer.from('c3878546c453bca783fd91965218242eecc32d5443764d4a7f233ff018f002e0', 'hex'),
    network,
);

const psbtTransactionData2: FromBase64Params = {
    signer: rlSigner2,
    network: network,
};

const psbtTransaction2 = PsbtTransaction.fromBase64(
    'AHBzYnT/AQCJAgAAAAGqpr9zTL0OUcMPJqSjy18vGXoaAwonXBXnpciJFtGgggEAAAAA/f///wLgP+4FAAAAACIAIPxalL3e9VOleQh1cyXELH155fo5VCUAMolPgEQO/yfFSgEAAAAAAAAiUSDL4fsq34Gxa6Svuzh0P0c4zLKBcNLvw1o8qTZs5k6kUQAAAAAAAQErAOH1BQAAAAAiACD8WpS93vVTpXkIdXMlxCx9eeX6OVQlADKJT4BEDv8nxSICAgPmjuI2/MNJM9STswWm8MdWEllHHRPs0Q3+DjdjOny+RzBEAiAZRgcFaRr39GY9sko5lKWov4g4i+77dNzCMKHR2WUbHQIgaPfYFjQZt0sCItEkosLeCZD94VPH4T2q/pZXP//x/luBAQMEgQAAAAEFi1IhAgPmjuI2/MNJM9STswWm8MdWEllHHRPs0Q3+DjdjOny+IQLTjqWw7J4i27NkBrqjxbuwJwjivZTUkpfqbz69JtGMdyEDgkTBMHBPHlBosIU5FOjDbtRC+QtBZmC6HPo353wVzMghA7ZKMoDQJlcQNbzIikCE5MPiFC81RvHHTeTMRx2/bFiOVK4AAAA=',
    psbtTransactionData2,
);

psbtTransaction2.ignoreSignatureError();
const s = psbtTransaction2.attemptSignAllInputs();
const f = psbtTransaction2.attemptFinalizeInputs(1);

console.log(psbtTransaction2, s, f);

const newPsbt = psbtTransaction2.getTransaction().toHex();
console.log(newPsbt);

//psbtTransaction.joinPSBT(originalTx);
//console.log(psbtTransaction.toBase64());

/*

const psbtTransactionData2: FromBase64Params = {
    signer: realSigner.keypair,
    network: network,
    amountRequested: 10000n,
    receiver: wallet.p2tr,
};

const newTx = PsbtTransaction.fromBase64(psbtTransaction.toBase64(), psbtTransactionData2);
const signed = newTx.attemptSignAllInputs();
console.log(signed, signed, newTx.toBase64());

const rlSigner2 = EcKeyPair.fromPrivateKey(
    Buffer.from('c3878546c453bca783fd91965218242eecc32d5443764d4a7f233ff018f002e0', 'hex'),
    network,
);
const psbtTransactionData3: FromBase64Params = {
    signer: rlSigner2,
    network: network,
    amountRequested: 10000n,
    receiver: wallet.p2tr,
};

const newTx2 = PsbtTransaction.fromBase64(newTx.toBase64(), psbtTransactionData3);
const signed3 = newTx2.attemptSignAllInputs();
const finalized = newTx2.attemptFinalizeInputs(0, toXOnly(wallet.publicKey));

console.log(signed3, finalized);

const extracted = newTx2.getTransaction().toHex();
console.log(extracted);
*/
